package bankads;

public class BankADS {

    public static void main(String[] args) {
        
        ContaCorrente anna = new ContaCorrente("Anna");      //objeto ContaCorrente ANNA
        anna.depositar(2000);
       
        try {
            anna.sacar(20);
            System.out.println("anna - Saque efetuado com sucesso");
        }catch (SacarException ex) {
            System.out.println("anna - Saque não realizado :" + ex.getMessage());
        }
       
        ContaCorrente bruna = new ContaCorrente("Bruna");    //objeto ContaCorrente BRUNA
       
        try {                                    //transferencia ANNA para BRUNA
            anna.transferir(bruna, 300);    
            System.out.println("Transferencia Anna -> Bruna efetuada com sucesso");
            bruna.sacar(10);
            System.out.println("bruna - Saque efetuado com sucesso");
        }catch (TransferirException ex) {
            System.out.println("Erro na Transferencia");
        }catch (SacarException ex) {
            System.out.println("bruna - Erro no saque");
        }catch (Exception ex) {
            System.out.println("Algo não realizado");
        }
        
        ContaEspecial camila = new ContaEspecial("Camila");     //objeto ContaEspecial CAMILA
        camila.depositar(100);
        camila.setLimite(100);
        
        try {
            camila.sacar(150);
            System.out.println("camila - Saque efetuado");
        } catch(SacarException ex) {
            System.out.println("camila - Erro ao sacar");
        }
        
        try {
            bruna.transferir(camila, 10);
            System.out.println("Transferencia Bruna -> Camila efetuada com sucesso");
        } catch(TransferirException ex) {
            System.out.println("Transferencia Bruna -> Camila invalida");
        }
       
        //Exibição dos dados de ANNA e BRUNA
        System.out.println("");
        System.out.println("-----------------------------------------------");
        System.out.println(anna.getNome() + " " + anna.getSaldo());
        System.out.println(bruna.getNome() + " " + bruna.getSaldo());
        System.out.println(camila.getNome() + " " + camila.getSaldo());

        System.out.println("-----------------------------------------------");
    }
    
}
