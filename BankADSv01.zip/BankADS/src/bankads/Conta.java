package bankads;

public abstract class Conta implements IConta {
    protected double saldo;
    protected String nome;
    
    public Conta(String nome) {
        this.nome = nome;
        this.saldo = 0.0;
    }
    
    @Override
    public void depositar(double valor) {
        this.saldo += valor;
    }
    
    @Override
    public abstract void sacar(double valor) throws SacarException;
    
    public void transferir(IConta favorecido, double valor) throws TransferirException {
        try {
            this.sacar(valor);
            favorecido.depositar(valor);
        } catch(SacarException ex) {
            throw new TransferirException("Transferencia nao realizada");
        }
         
    }
    
    public double getSaldo() {
        return saldo;
    }
    
    public String getNome() {
        return nome;
    }
    
    
}
