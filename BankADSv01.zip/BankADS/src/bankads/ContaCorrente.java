package bankads;

public class ContaCorrente extends Conta {
    public ContaCorrente(String nome) {
        super(nome);
    }
    
    @Override
    public void sacar(double valor) throws SacarException {
        if(saldo >= valor) {
            this.saldo -= valor;
        }else {
            //System.out.println("Saldo insuficiente!");
            throw new SacarException("Saldo insuficiente");
        }
    }
}
