package bankads;

public class ContaEspecial extends Conta {
    private double limite;
    
    public ContaEspecial(String nome) {
        super(nome);
        this.limite = 0.0;
    }
    
    @Override
    public void sacar(double valor) throws SacarException {
        if(saldo + limite >= valor) {
            this.saldo -= valor;
        }else {
            //System.out.println("Saldo insuficiente!");
            throw new SacarException("Saldo insuficiente");
        }
        
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    
}
