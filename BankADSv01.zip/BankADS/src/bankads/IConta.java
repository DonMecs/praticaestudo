package bankads;

public interface IConta {
    void sacar(double valor) throws SacarException;
    void depositar(double valor);
}
