package bankads;

public class SacarException extends Exception {
    
    public SacarException(String message) {
        super(message);
    }
}
