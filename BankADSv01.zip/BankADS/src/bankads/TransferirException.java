package bankads;

public class TransferirException extends Exception {
    
    public TransferirException(String message) {
        super(message);
    }
}
