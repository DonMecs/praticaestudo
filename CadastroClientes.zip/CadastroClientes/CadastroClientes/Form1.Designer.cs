﻿namespace CadastroClientes
{
    partial class fm_cadastro
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fm_cadastro));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_nome = new System.Windows.Forms.Label();
            this.tb_nome = new System.Windows.Forms.TextBox();
            this.lb_sobrenome = new System.Windows.Forms.Label();
            this.tb_sobrenome = new System.Windows.Forms.TextBox();
            this.tb_email2 = new System.Windows.Forms.TextBox();
            this.lb_email2 = new System.Windows.Forms.Label();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_nascimento = new System.Windows.Forms.Label();
            this.lb_celular = new System.Windows.Forms.Label();
            this.lb_cpf = new System.Windows.Forms.Label();
            this.tb_rg = new System.Windows.Forms.TextBox();
            this.lb_rg = new System.Windows.Forms.Label();
            this.lb_estadocivil = new System.Windows.Forms.Label();
            this.tb_endereco = new System.Windows.Forms.TextBox();
            this.lb_endereco = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_numero = new System.Windows.Forms.TextBox();
            this.lb_numero = new System.Windows.Forms.Label();
            this.lb_estado = new System.Windows.Forms.Label();
            this.tb_cidade = new System.Windows.Forms.TextBox();
            this.lb_cidade = new System.Windows.Forms.Label();
            this.dt_nascimento = new System.Windows.Forms.DateTimePicker();
            this.cb_estado = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rb_viuvo = new System.Windows.Forms.RadioButton();
            this.rb_separado = new System.Windows.Forms.RadioButton();
            this.rb_divorciado = new System.Windows.Forms.RadioButton();
            this.rb_casado = new System.Windows.Forms.RadioButton();
            this.rb_solteiro = new System.Windows.Forms.RadioButton();
            this.mtb_celular = new System.Windows.Forms.MaskedTextBox();
            this.mtb_cpf = new System.Windows.Forms.MaskedTextBox();
            this.lb_aviso = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirNovoProjetoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(26, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "CADASTRO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.CadetBlue;
            this.label2.Location = new System.Drawing.Point(27, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(498, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "_________________________________________________";
            // 
            // lb_nome
            // 
            this.lb_nome.AutoSize = true;
            this.lb_nome.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nome.Location = new System.Drawing.Point(27, 107);
            this.lb_nome.Name = "lb_nome";
            this.lb_nome.Size = new System.Drawing.Size(43, 16);
            this.lb_nome.TabIndex = 2;
            this.lb_nome.Text = "Nome";
            // 
            // tb_nome
            // 
            this.tb_nome.BackColor = System.Drawing.Color.Beige;
            this.tb_nome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_nome.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_nome.Location = new System.Drawing.Point(30, 129);
            this.tb_nome.Name = "tb_nome";
            this.tb_nome.Size = new System.Drawing.Size(223, 20);
            this.tb_nome.TabIndex = 3;
            // 
            // lb_sobrenome
            // 
            this.lb_sobrenome.AutoSize = true;
            this.lb_sobrenome.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sobrenome.Location = new System.Drawing.Point(289, 107);
            this.lb_sobrenome.Name = "lb_sobrenome";
            this.lb_sobrenome.Size = new System.Drawing.Size(80, 16);
            this.lb_sobrenome.TabIndex = 4;
            this.lb_sobrenome.Text = "Sobrenome";
            // 
            // tb_sobrenome
            // 
            this.tb_sobrenome.BackColor = System.Drawing.Color.Beige;
            this.tb_sobrenome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_sobrenome.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_sobrenome.Location = new System.Drawing.Point(292, 129);
            this.tb_sobrenome.Name = "tb_sobrenome";
            this.tb_sobrenome.Size = new System.Drawing.Size(223, 20);
            this.tb_sobrenome.TabIndex = 5;
            // 
            // tb_email2
            // 
            this.tb_email2.BackColor = System.Drawing.Color.Beige;
            this.tb_email2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_email2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_email2.Location = new System.Drawing.Point(292, 186);
            this.tb_email2.Name = "tb_email2";
            this.tb_email2.Size = new System.Drawing.Size(223, 20);
            this.tb_email2.TabIndex = 9;
            // 
            // lb_email2
            // 
            this.lb_email2.AutoSize = true;
            this.lb_email2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email2.Location = new System.Drawing.Point(289, 164);
            this.lb_email2.Name = "lb_email2";
            this.lb_email2.Size = new System.Drawing.Size(98, 16);
            this.lb_email2.TabIndex = 8;
            this.lb_email2.Text = "Repetir e-mail";
            // 
            // tb_email
            // 
            this.tb_email.BackColor = System.Drawing.Color.Beige;
            this.tb_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_email.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_email.Location = new System.Drawing.Point(30, 186);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(223, 20);
            this.tb_email.TabIndex = 7;
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email.Location = new System.Drawing.Point(27, 164);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(47, 16);
            this.lb_email.TabIndex = 6;
            this.lb_email.Text = "E-mail";
            // 
            // lb_nascimento
            // 
            this.lb_nascimento.AutoSize = true;
            this.lb_nascimento.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nascimento.Location = new System.Drawing.Point(289, 220);
            this.lb_nascimento.Name = "lb_nascimento";
            this.lb_nascimento.Size = new System.Drawing.Size(139, 16);
            this.lb_nascimento.TabIndex = 12;
            this.lb_nascimento.Text = "Data de nascimento";
            // 
            // lb_celular
            // 
            this.lb_celular.AutoSize = true;
            this.lb_celular.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_celular.Location = new System.Drawing.Point(27, 220);
            this.lb_celular.Name = "lb_celular";
            this.lb_celular.Size = new System.Drawing.Size(51, 16);
            this.lb_celular.TabIndex = 10;
            this.lb_celular.Text = "Celular";
            // 
            // lb_cpf
            // 
            this.lb_cpf.AutoSize = true;
            this.lb_cpf.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cpf.Location = new System.Drawing.Point(289, 279);
            this.lb_cpf.Name = "lb_cpf";
            this.lb_cpf.Size = new System.Drawing.Size(32, 16);
            this.lb_cpf.TabIndex = 16;
            this.lb_cpf.Text = "CPF";
            // 
            // tb_rg
            // 
            this.tb_rg.BackColor = System.Drawing.Color.Beige;
            this.tb_rg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_rg.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_rg.Location = new System.Drawing.Point(30, 301);
            this.tb_rg.Name = "tb_rg";
            this.tb_rg.Size = new System.Drawing.Size(223, 20);
            this.tb_rg.TabIndex = 15;
            // 
            // lb_rg
            // 
            this.lb_rg.AutoSize = true;
            this.lb_rg.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_rg.Location = new System.Drawing.Point(27, 279);
            this.lb_rg.Name = "lb_rg";
            this.lb_rg.Size = new System.Drawing.Size(24, 16);
            this.lb_rg.TabIndex = 14;
            this.lb_rg.Text = "RG";
            // 
            // lb_estadocivil
            // 
            this.lb_estadocivil.AutoSize = true;
            this.lb_estadocivil.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_estadocivil.Location = new System.Drawing.Point(27, 337);
            this.lb_estadocivil.Name = "lb_estadocivil";
            this.lb_estadocivil.Size = new System.Drawing.Size(83, 16);
            this.lb_estadocivil.TabIndex = 18;
            this.lb_estadocivil.Text = "Estado Civil";
            // 
            // tb_endereco
            // 
            this.tb_endereco.BackColor = System.Drawing.Color.Beige;
            this.tb_endereco.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_endereco.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_endereco.Location = new System.Drawing.Point(30, 414);
            this.tb_endereco.Name = "tb_endereco";
            this.tb_endereco.Size = new System.Drawing.Size(485, 20);
            this.tb_endereco.TabIndex = 21;
            // 
            // lb_endereco
            // 
            this.lb_endereco.AutoSize = true;
            this.lb_endereco.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_endereco.Location = new System.Drawing.Point(27, 392);
            this.lb_endereco.Name = "lb_endereco";
            this.lb_endereco.Size = new System.Drawing.Size(68, 16);
            this.lb_endereco.TabIndex = 20;
            this.lb_endereco.Text = "Endereço";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Beige;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox5.Location = new System.Drawing.Point(292, 469);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(223, 20);
            this.textBox5.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(289, 447);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Complemento";
            // 
            // tb_numero
            // 
            this.tb_numero.BackColor = System.Drawing.Color.Beige;
            this.tb_numero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_numero.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_numero.Location = new System.Drawing.Point(30, 469);
            this.tb_numero.Name = "tb_numero";
            this.tb_numero.Size = new System.Drawing.Size(223, 20);
            this.tb_numero.TabIndex = 23;
            // 
            // lb_numero
            // 
            this.lb_numero.AutoSize = true;
            this.lb_numero.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_numero.Location = new System.Drawing.Point(27, 447);
            this.lb_numero.Name = "lb_numero";
            this.lb_numero.Size = new System.Drawing.Size(56, 16);
            this.lb_numero.TabIndex = 22;
            this.lb_numero.Text = "Número";
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_estado.Location = new System.Drawing.Point(289, 501);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(52, 16);
            this.lb_estado.TabIndex = 28;
            this.lb_estado.Text = "Estado";
            // 
            // tb_cidade
            // 
            this.tb_cidade.BackColor = System.Drawing.Color.Beige;
            this.tb_cidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_cidade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tb_cidade.Location = new System.Drawing.Point(30, 523);
            this.tb_cidade.Name = "tb_cidade";
            this.tb_cidade.Size = new System.Drawing.Size(223, 20);
            this.tb_cidade.TabIndex = 27;
            // 
            // lb_cidade
            // 
            this.lb_cidade.AutoSize = true;
            this.lb_cidade.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cidade.Location = new System.Drawing.Point(27, 501);
            this.lb_cidade.Name = "lb_cidade";
            this.lb_cidade.Size = new System.Drawing.Size(51, 16);
            this.lb_cidade.TabIndex = 26;
            this.lb_cidade.Text = "Cidade";
            // 
            // dt_nascimento
            // 
            this.dt_nascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dt_nascimento.Location = new System.Drawing.Point(292, 239);
            this.dt_nascimento.Name = "dt_nascimento";
            this.dt_nascimento.Size = new System.Drawing.Size(223, 27);
            this.dt_nascimento.TabIndex = 29;
            // 
            // cb_estado
            // 
            this.cb_estado.BackColor = System.Drawing.Color.Beige;
            this.cb_estado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_estado.FormattingEnabled = true;
            this.cb_estado.Items.AddRange(new object[] {
            "Acre (AC)",
            "Alagoas (AL)",
            "Amapá (AP)",
            "Amazonas (AM)",
            "Bahia (BA)",
            "Ceará (CE)",
            "Distrito Federal (DF)",
            "Espírito Santo (ES)",
            "Goiás (GO)",
            "Maranhão (MA)",
            "Mato Grosso (MT)",
            "Mato Grosso do Sul (MS)",
            "Minas Gerais (MG)",
            "Pará (PA)",
            "Paraíba (PB)",
            "Paraná (PR)",
            "Pernambuco (PE)",
            "Piauí (PI)",
            "Rio de Janeiro (RJ)",
            "Rio Grande do Norte (RN)",
            "Rio Grande do Sul (RS)",
            "Rondônia (RO)",
            "Roraima (RR)",
            "Santa Catarina (SC)",
            "São Paulo (SP)",
            "Sergipe (SE)",
            "Tocantins (TO)"});
            this.cb_estado.Location = new System.Drawing.Point(292, 521);
            this.cb_estado.Name = "cb_estado";
            this.cb_estado.Size = new System.Drawing.Size(223, 26);
            this.cb_estado.TabIndex = 30;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.ForeColor = System.Drawing.Color.LightCyan;
            this.button1.Location = new System.Drawing.Point(30, 564);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(485, 30);
            this.button1.TabIndex = 31;
            this.button1.Text = "ENVIAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Click_verificarCampos);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.Controls.Add(this.rb_viuvo);
            this.panel1.Controls.Add(this.rb_separado);
            this.panel1.Controls.Add(this.rb_divorciado);
            this.panel1.Controls.Add(this.rb_casado);
            this.panel1.Controls.Add(this.rb_solteiro);
            this.panel1.Location = new System.Drawing.Point(30, 356);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(485, 30);
            this.panel1.TabIndex = 32;
            // 
            // rb_viuvo
            // 
            this.rb_viuvo.AutoSize = true;
            this.rb_viuvo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_viuvo.Location = new System.Drawing.Point(421, 5);
            this.rb_viuvo.Name = "rb_viuvo";
            this.rb_viuvo.Size = new System.Drawing.Size(61, 20);
            this.rb_viuvo.TabIndex = 4;
            this.rb_viuvo.TabStop = true;
            this.rb_viuvo.Text = "Viúvo";
            this.rb_viuvo.UseVisualStyleBackColor = true;
            // 
            // rb_separado
            // 
            this.rb_separado.AutoSize = true;
            this.rb_separado.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_separado.Location = new System.Drawing.Point(311, 5);
            this.rb_separado.Name = "rb_separado";
            this.rb_separado.Size = new System.Drawing.Size(87, 20);
            this.rb_separado.TabIndex = 3;
            this.rb_separado.TabStop = true;
            this.rb_separado.Text = "Separado";
            this.rb_separado.UseVisualStyleBackColor = true;
            // 
            // rb_divorciado
            // 
            this.rb_divorciado.AutoSize = true;
            this.rb_divorciado.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_divorciado.Location = new System.Drawing.Point(198, 5);
            this.rb_divorciado.Name = "rb_divorciado";
            this.rb_divorciado.Size = new System.Drawing.Size(93, 20);
            this.rb_divorciado.TabIndex = 2;
            this.rb_divorciado.TabStop = true;
            this.rb_divorciado.Text = "Divorciado";
            this.rb_divorciado.UseVisualStyleBackColor = true;
            // 
            // rb_casado
            // 
            this.rb_casado.AutoSize = true;
            this.rb_casado.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_casado.Location = new System.Drawing.Point(100, 5);
            this.rb_casado.Name = "rb_casado";
            this.rb_casado.Size = new System.Drawing.Size(73, 20);
            this.rb_casado.TabIndex = 1;
            this.rb_casado.TabStop = true;
            this.rb_casado.Text = "Casado";
            this.rb_casado.UseVisualStyleBackColor = true;
            // 
            // rb_solteiro
            // 
            this.rb_solteiro.AutoSize = true;
            this.rb_solteiro.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_solteiro.Location = new System.Drawing.Point(3, 5);
            this.rb_solteiro.Name = "rb_solteiro";
            this.rb_solteiro.Size = new System.Drawing.Size(75, 20);
            this.rb_solteiro.TabIndex = 0;
            this.rb_solteiro.TabStop = true;
            this.rb_solteiro.Text = "Solteiro";
            this.rb_solteiro.UseVisualStyleBackColor = true;
            // 
            // mtb_celular
            // 
            this.mtb_celular.BackColor = System.Drawing.Color.Beige;
            this.mtb_celular.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.mtb_celular.Location = new System.Drawing.Point(30, 242);
            this.mtb_celular.Mask = "(99) 0000-0000";
            this.mtb_celular.Name = "mtb_celular";
            this.mtb_celular.Size = new System.Drawing.Size(223, 27);
            this.mtb_celular.TabIndex = 33;
            // 
            // mtb_cpf
            // 
            this.mtb_cpf.BackColor = System.Drawing.Color.Beige;
            this.mtb_cpf.Culture = new System.Globalization.CultureInfo("en-US");
            this.mtb_cpf.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.mtb_cpf.Location = new System.Drawing.Point(292, 299);
            this.mtb_cpf.Mask = "000.000.000-00";
            this.mtb_cpf.Name = "mtb_cpf";
            this.mtb_cpf.Size = new System.Drawing.Size(220, 27);
            this.mtb_cpf.TabIndex = 34;
            // 
            // lb_aviso
            // 
            this.lb_aviso.AutoSize = true;
            this.lb_aviso.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_aviso.ForeColor = System.Drawing.Color.Tomato;
            this.lb_aviso.Location = new System.Drawing.Point(289, 41);
            this.lb_aviso.Name = "lb_aviso";
            this.lb_aviso.Size = new System.Drawing.Size(80, 16);
            this.lb_aviso.TabIndex = 35;
            this.lb_aviso.Text = "Sobrenome";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.sobreToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(549, 24);
            this.menuStrip1.TabIndex = 36;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salvarToolStripMenuItem,
            this.abrirNovoProjetoToolStripMenuItem,
            this.toolStripSeparator1,
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.salvarToolStripMenuItem.Text = "Salvar";
            // 
            // abrirNovoProjetoToolStripMenuItem
            // 
            this.abrirNovoProjetoToolStripMenuItem.Name = "abrirNovoProjetoToolStripMenuItem";
            this.abrirNovoProjetoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.abrirNovoProjetoToolStripMenuItem.Text = "Abrir novo projeto";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairPrograma);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sobreToolStripMenuItem.Text = "Sobre";
            // 
            // fm_cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(549, 619);
            this.Controls.Add(this.lb_aviso);
            this.Controls.Add(this.mtb_cpf);
            this.Controls.Add(this.mtb_celular);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cb_estado);
            this.Controls.Add(this.dt_nascimento);
            this.Controls.Add(this.lb_estado);
            this.Controls.Add(this.tb_cidade);
            this.Controls.Add(this.lb_cidade);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tb_numero);
            this.Controls.Add(this.lb_numero);
            this.Controls.Add(this.tb_endereco);
            this.Controls.Add(this.lb_endereco);
            this.Controls.Add(this.lb_estadocivil);
            this.Controls.Add(this.lb_cpf);
            this.Controls.Add(this.tb_rg);
            this.Controls.Add(this.lb_rg);
            this.Controls.Add(this.lb_nascimento);
            this.Controls.Add(this.lb_celular);
            this.Controls.Add(this.tb_email2);
            this.Controls.Add(this.lb_email2);
            this.Controls.Add(this.tb_email);
            this.Controls.Add(this.lb_email);
            this.Controls.Add(this.tb_sobrenome);
            this.Controls.Add(this.lb_sobrenome);
            this.Controls.Add(this.tb_nome);
            this.Controls.Add(this.lb_nome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "fm_cadastro";
            this.Text = "Cadastro";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fecharPrograma);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_nome;
        private System.Windows.Forms.TextBox tb_nome;
        private System.Windows.Forms.Label lb_sobrenome;
        private System.Windows.Forms.TextBox tb_sobrenome;
        private System.Windows.Forms.TextBox tb_email2;
        private System.Windows.Forms.Label lb_email2;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.Label lb_nascimento;
        private System.Windows.Forms.Label lb_celular;
        private System.Windows.Forms.Label lb_cpf;
        private System.Windows.Forms.TextBox tb_rg;
        private System.Windows.Forms.Label lb_rg;
        private System.Windows.Forms.Label lb_estadocivil;
        private System.Windows.Forms.TextBox tb_endereco;
        private System.Windows.Forms.Label lb_endereco;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_numero;
        private System.Windows.Forms.Label lb_numero;
        private System.Windows.Forms.Label lb_estado;
        private System.Windows.Forms.TextBox tb_cidade;
        private System.Windows.Forms.Label lb_cidade;
        private System.Windows.Forms.DateTimePicker dt_nascimento;
        private System.Windows.Forms.ComboBox cb_estado;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_casado;
        private System.Windows.Forms.RadioButton rb_solteiro;
        private System.Windows.Forms.RadioButton rb_viuvo;
        private System.Windows.Forms.RadioButton rb_separado;
        private System.Windows.Forms.RadioButton rb_divorciado;
        private System.Windows.Forms.MaskedTextBox mtb_celular;
        private System.Windows.Forms.MaskedTextBox mtb_cpf;
        private System.Windows.Forms.Label lb_aviso;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirNovoProjetoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
    }
}

