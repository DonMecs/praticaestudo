﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CadastroClientes
{
    public partial class fm_cadastro : Form
    {
        public fm_cadastro()
        {
            InitializeComponent();
            lb_aviso.Visible = false;
        }

        private void Click_verificarCampos(object sender, EventArgs e)
        {
            if (tb_nome.Text == string.Empty)               // verifica o valor da textbox de nome
            {
                lb_nome.ForeColor = Color.Red;
            }else
            {
                lb_nome.ForeColor = Color.LightSeaGreen;
            }

            if (tb_sobrenome.Text == string.Empty)          // verifica o valor da textbox de sobrenome
            {
                lb_sobrenome.ForeColor = Color.Red;
            }
            else
            {
                lb_sobrenome.ForeColor = Color.LightSeaGreen;
            }

            if (tb_rg.Text == string.Empty)                 // verifica o valor da textbox de rg
            {
                lb_rg.ForeColor = Color.Red;
            }
            else
            {
                lb_rg.ForeColor = Color.LightSeaGreen;
            }

            if (tb_endereco.Text == string.Empty)           // verifica o valor da textbox de endereco
            {
                lb_endereco.ForeColor = Color.Red;
            }
            else
            {
                lb_endereco.ForeColor = Color.LightSeaGreen;
            }

            if (tb_numero.Text == string.Empty)             // verifica o valor da textbox de numero
            {
                lb_numero.ForeColor = Color.Red;
            }
            else
            {
                lb_numero.ForeColor = Color.LightSeaGreen;
            }

            if (tb_cidade.Text == string.Empty)             // verifica o valor da textbox de Cidade
            {
                lb_cidade.ForeColor = Color.Red;
            }
            else
            {
                lb_cidade.ForeColor = Color.LightSeaGreen;
            }

            if (tb_email.Text == string.Empty)              // verifica o valor da textbox de email
            {
                lb_email.ForeColor = Color.Red;
            }
            else
            {
                lb_email.ForeColor = Color.LightSeaGreen;
            }

            if (tb_email2.Text == string.Empty)             // verifica o valor da textbox de repetir email
            {
                lb_email2.ForeColor = Color.Red;
            }
            else
            {
                lb_email2.ForeColor = Color.LightSeaGreen;
            }

            if (!(String.Equals(tb_email.Text,tb_email2.Text)))  // verifica se tb_email e tb_email2 possuem o mesmo valor
            {                                                    // caso não seja, exibe uma label apontando o erro
                lb_aviso.Text = "E-mail está incorreto.";
                lb_aviso.Visible = true;
            }
            else 
            {
                lb_aviso.Visible = false;
            }

            if (cb_estado.Text == string.Empty)             // verifica o valor da combobox de estado
            {
                lb_estado.ForeColor = Color.Red;
            }
            else
            {
                lb_estado.ForeColor = Color.LightSeaGreen;
            }

            if (mtb_celular.MaskFull == false)              // verifica o valor da mtb de celular
            {
                lb_celular.ForeColor = Color.Red;
            }
            else
            {
                lb_celular.ForeColor = Color.LightSeaGreen;
            }

            if (mtb_cpf.MaskFull == false)                  // verifica o valor da mtb de cpf
            {
                lb_cpf.ForeColor = Color.Red;
            }
            else
            {
                lb_cpf.ForeColor = Color.LightSeaGreen;
            }
                        
            if ((rb_casado.Checked == false) && (rb_divorciado.Checked == false)    // verifica o radio button de
                && (rb_separado.Checked == false) && (rb_solteiro.Checked == false) // estado civil
                && (rb_viuvo.Checked == false))
            {
                lb_estadocivil.ForeColor = Color.Red;
            }
            else
            {
                lb_estadocivil.ForeColor = Color.LightSeaGreen;
            }
        }

        private void sairPrograma(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fecharPrograma(object sender, FormClosingEventArgs e)
        {

        }
    }
}
