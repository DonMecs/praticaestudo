package gestaodealuno;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
    private String nome;
    private String ra;
    private double notaB1;
    private double notaB2;
    private Endereco endereco;
    private Telefone telefoneResidencial;
    private Telefone telefoneComercial;
    private List<Telefone> telefones;
    
    Aluno() { 
       telefones = new ArrayList<Telefone>();            
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }
    
    public double getNotaB1() {
        return notaB1;
    }

    public void setNotaB1(double notaB1) {
        this.notaB1 = notaB1;
    }

    public double getNotaB2() {
        return notaB2;
    }

    public void setNotaB2(double notaB2) {
        this.notaB2 = notaB2;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }  

    public Telefone getTelefoneResidencial() {
        return telefoneResidencial;
    }

    public void setTelefoneResidencial(Telefone telefoneResidencial) {
        this.telefoneResidencial = telefoneResidencial;
    }

    public Telefone getTelefoneComercial() {
        return telefoneComercial;
    }

    public void setTelefoneComercial(Telefone telefoneComercial) {
        this.telefoneComercial = telefoneComercial;
    }

    public List<Telefone> getTelefones() {
        return telefones;
    }

    public void setTelefones(List<Telefone> telefones) {
        this.telefones = telefones;
    }
   
    
    
    public void addTelefone(Telefone telefone) {
        telefones.add(telefone);
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", ra=" + ra + ", notaB1=" + notaB1 + ", notaB2=" + notaB2 + ", endereco=" + endereco + ", telefoneResidencial=" + telefoneResidencial + ", telefoneComercial=" + telefoneComercial + ", telefones=" + telefones + '}';
    }
    
   
   
   









}
