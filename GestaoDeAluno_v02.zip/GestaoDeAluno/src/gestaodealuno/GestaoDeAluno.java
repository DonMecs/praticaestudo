package gestaodealuno;

import java.util.ArrayList;
import java.util.List;

public class GestaoDeAluno {

    public static void main(String[] args) {
        Aluno kayky = new Aluno();
        kayky.setNome("Kayky");
        kayky.setEndereco(new Endereco());
        kayky.getEndereco().setRua("Sao Paulo");
        kayky.getEndereco().setNumero(666);
        kayky.getEndereco().setBairro("Bonfim");
        kayky.setTelefoneResidencial(new Telefone("016","959595"));
        kayky.addTelefone(new Telefone("016", "98989899"));
        kayky.addTelefone(new Telefone("016", "090903334"));
    
        Aluno justin = new Aluno();
        justin.setNome("Nome");
        justin.setEndereco(kayky.getEndereco().copia());
        justin.getEndereco().setRua("Alagoas");
        justin.setTelefoneResidencial(new Telefone());
        justin.getTelefoneResidencial().setDdd("16");
        justin.getTelefoneResidencial().setNumero("909009090");
        justin.setTelefoneComercial(new Telefone("016", "37289393"));
        
        List<String> palavras = new ArrayList<String>();
        palavras.add("A de amor,");
        palavras.add("B de baby,");
        palavras.add("C de csharp,");
        palavras.add("D de dudu,");
        
        for(String p:palavras) {
            System.out.println(p);
        }
        
        System.out.println(kayky);
        System.out.println(justin);
    }
    
}
